# main.py

from interfaz import InterfazAnalizador

def main():
    app = InterfazAnalizador()
    app.run()

if __name__ == "__main__":
    main()
